import React, { useState, useEffect } from 'react';
import './App.css';


const result = "DOCTOR REPORT";
const down = "result : clean";


function App() {
  const [showBoard, setShowBoard] = useState(false);

  useEffect(() => {
    
    const timeout = setTimeout(() => {
      setShowBoard(true);
    }, 500);

    return () => clearTimeout(timeout);
  }, []);

  return (
    <div className={`App ${showBoard ? 'show' : ''}`}>
      <header className="App-header">
        <div className={`doctor-board ${showBoard ? 'rotate' : ''}`}>
          <h1>{result}</h1>
          <div className="patient-info">
            <p>{down}</p>
          </div>
        </div>
      </header>
    </div>
  );
}

export default App;
