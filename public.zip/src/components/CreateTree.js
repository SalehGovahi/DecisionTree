import React, { Component } from 'react';
import './CreateTree.css'; // Import your CSS file

class CreateTree extends Component {
  constructor(props) {
    super(props);
    this.state = {
      featureNames: [
        'HighBP',
        'HighChol',
        'CholCheck',
        'Smoker',
        'Stroke',
        'HeartDiseaseorAttack',
        'PhysActivity',
        'Fruits',
        'Veggies',
        'HvyAlcoholConsump',
        'AnyHealthcare',
        'NoDocbcCost',
        'GenHlth',
        'DiffWalk',
        'Sex',
        'Education',
        'Income',
      ],
      inputs: Array(17).fill(''), // Initialize inputs array with 17 empty strings
      showChart: false, // Track whether to show the Chart component
    };
  }

  handleInputChange = (index, event) => {
    const newInputs = [...this.state.inputs];
    newInputs[index] = event.target.value;
    this.setState({ inputs: newInputs });
  };

  handleSave = () => {
    const dataToSave = {
      features: this.state.featureNames,
      values: this.state.inputs,
    };

    // Convert the data to a JSON string
    const jsonData = JSON.stringify(dataToSave);

    // Create a Blob from the JSON data
    const blob = new Blob([jsonData], { type: 'application/json' });

    // Create a link element and trigger a click event to download the file
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'savedFeatures.json';
    a.click();
  };

  render() {
    return (
      <div className="create-tree-container">
        <div className="header">
          <h1>Input Page</h1>
        </div>
        <div className="input-fields">
          {this.state.featureNames.map((featureName, index) => (
            <div key={index} className="input-field">
              <label>{`${featureName}:`}</label>
              <input
                type="text"
                value={this.state.inputs[index]}
                onChange={(event) => this.handleInputChange(index, event)}
              />
            </div>
          ))}
        </div>
        <button onClick={this.handleSave}>Save</button>
      </div>
    );
  }
}

export default CreateTree;
