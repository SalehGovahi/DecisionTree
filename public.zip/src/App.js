import React from 'react';
import CreateTree from './components/CreateTree';


function App() {
  return (
    <div>
      <CreateTree />
      
    </div>
  );
}

export default App;
