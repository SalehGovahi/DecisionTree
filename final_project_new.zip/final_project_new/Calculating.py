import pandas as pd
import numpy as np


# Provided data
data = np.array([
    [1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 5, 1, 0, 3, 2],
    [0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 2, 0, 0, 4, 6],
    [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 4, 1, 0, 5, 2],
    [0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 2, 0, 0, 6, 8],
    [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3, 0, 1, 6, 7]
])

labels_diabetes = np.array([0, 0, 0, 2, 0])

# Combine features and labels into a DataFrame
columns = ["HighBP", "HighChol", "CholCheck", "Smoker", "Stroke", "HeartDiseaseorAttack",
           "PhysActivity", "Fruits", "Veggies", "HvyAlcoholConsump", "AnyHealthcare",
           "NoDocbcCost", "GenHlth", "DiffWalk", "Sex", "Education", "Income", "Diabetes_012"]

df = pd.DataFrame(np.column_stack((data, labels_diabetes)), columns=columns)


def calculate_entropy(labels):
    unique_labels, counts = np.unique(labels, return_counts=True)
    probabilities = counts / len(labels)
    entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))  # Add a small value to prevent log(0)
    return entropy


def calculate_information_gain(data, labels, feature_name):
    # Calculate entropy of the parent node
    entropy_parent = calculate_entropy(labels)

    # Calculate weighted average entropy for each possible split
    unique_values = np.unique(data[feature_name])
    weighted_avg_entropy = 0

    for value in unique_values:
        subset_indices = data[feature_name] == value
        subset_labels = labels[subset_indices]
        weight = len(subset_labels) / len(labels)

        weighted_avg_entropy += weight * calculate_entropy(subset_labels)

    # Calculate information gain
    information_gain = entropy_parent - weighted_avg_entropy

    return information_gain


# Calculate information gain for each feature
information_gains = {}

for feature in columns[:-1]:  # Exclude the last column (Diabetes_012)
    gain = calculate_information_gain(df, labels_diabetes, feature)
    information_gains[feature] = gain

# Find the feature with the highest information gain
best_feature = max(information_gains, key=information_gains.get)

# print("Information Gains:")
# for feature, gain in information_gains.items():
#     print(f"{feature}: {gain}")
#
# print("\nBest Feature:", best_feature)
