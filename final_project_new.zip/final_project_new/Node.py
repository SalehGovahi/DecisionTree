class Node:
    def __init__(self, feature):
        self.feature = feature
        self.children = []


