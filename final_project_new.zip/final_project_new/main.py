import pandas as pd
import numpy as np

# Provided data
data = np.array([
    [1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 5, 1, 0, 3, 2],
    [0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 2, 0, 0, 4, 6],
    [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 4, 1, 0, 5, 2],
    [0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 2, 0, 0, 6, 8],
    [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3, 0, 1, 6, 7]
])

labels_diabetes = np.array([0, 0, 0, 2, 0])

# Combine features and labels into a DataFrame
columns = ["HighBP", "HighChol", "CholCheck", "Smoker", "Stroke", "HeartDiseaseorAttack",
           "PhysActivity", "Fruits", "Veggies", "HvyAlcoholConsump", "AnyHealthcare",
           "NoDocbcCost", "GenHlth", "DiffWalk", "Sex", "Education", "Income", "Diabetes_012"]

df = pd.DataFrame(np.column_stack((data, labels_diabetes)), columns=columns)


def calculate_entropy(labels):
    unique_labels, counts = np.unique(labels, return_counts=True)
    probabilities = counts / len(labels)
    entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))  # Add a small value to prevent log(0)
    return entropy


def calculate_information_gain(data, labels, feature_name):
    # Calculate entropy of the parent node
    entropy_parent = calculate_entropy(labels)

    # Calculate weighted average entropy for each possible split
    unique_values = np.unique(data[feature_name])
    weighted_avg_entropy = 0

    for value in unique_values:
        subset_indices = data[feature_name] == value
        subset_labels = labels[subset_indices]
        weight = len(subset_labels) / len(labels)

        weighted_avg_entropy += weight * calculate_entropy(subset_labels)

    # Calculate information gain
    information_gain = entropy_parent - weighted_avg_entropy

    return information_gain


# Calculate information gain for each feature
information_gains = {}

for feature in columns[:-1]:  # Exclude the last column (Diabetes_012)
    gain = calculate_information_gain(df, labels_diabetes, feature)
    information_gains[feature] = gain

# Find the feature with the highest information gain
best_feature = max(information_gains, key=information_gains.get)


# print("Information Gains:")
# for feature, gain in information_gains.items():
#     print(f"{feature}: {gain}")
#
# print("\nBest Feature:", best_feature)


class Node:
    def __init__(self, feature=None, value=None, result=None):
        self.feature = feature
        self.value = value
        self.result = result
        self.children = {}


def build_decision_tree(data, labels, features):
    # If all labels are the same, create a leaf node with the result
    if len(np.unique(labels)) == 1:
        return Node(result=labels[0])

    # If there are no features left, create a leaf node with the majority result
    if len(features) == 0:
        unique_labels, counts = np.unique(labels, return_counts=True)
        result = unique_labels[np.argmax(counts)]
        return Node(result=result)

    # Calculate information gains for remaining features
    information_gains = {}
    for feature in features:
        gain = calculate_information_gain(data, labels, feature)
        information_gains[feature] = gain

    # Find the feature with the highest information gain
    best_feature = max(information_gains, key=information_gains.get)

    # Create a new internal node with the best feature
    node = Node(feature=best_feature)

    # Recursively build subtrees for each unique value of the best feature
    unique_values = np.unique(data[best_feature])
    for value in unique_values:
        subset_indices = data[best_feature] == value
        subset_data = data[subset_indices]
        subset_labels = labels[subset_indices]

        # Remove the selected feature from the list of features
        remaining_features = [f for f in features if f != best_feature]

        # Recursively build subtree
        child_node = build_decision_tree(subset_data, subset_labels, remaining_features)

        # Add the subtree to the children of the current node
        node.children[value] = child_node

    return node


# Build the decision tree
root_node = build_decision_tree(df, labels_diabetes, columns[:-1])


# Function to visualize the decision tree
def print_tree(node, indent=""):
    if node.result is not None:
        print(indent + "Result:", node.result)
    else:
        print(indent + "Feature:", node.feature)
        for value, child_node in node.children.items():
            print(indent + f"Value {value}:")
            print_tree(child_node, indent + "  ")


# Print the decision tree
print_tree(root_node)
