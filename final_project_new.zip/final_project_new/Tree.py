from Node import Node
from Calculating import *


class Tree:
    def __init__(self):
        self.root = Node(best_feature)

    def show(self):
        print(self.root)